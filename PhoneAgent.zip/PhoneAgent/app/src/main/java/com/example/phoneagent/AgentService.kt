package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.*
import org.json.JSONObject
import kotlin.math.abs

class AgentService : AccessibilityService() {
    private class Screen(val text: String, val nodes: Map<Int, AccessibilityNodeInfo>, val pkg: String)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var confirmation: CompletableDeferred<Boolean>? = null
    private var panelOpen = false

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var rootView: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var confirmRow: LinearLayout

    override fun onServiceConnected() = buildOverlay()
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        scope.cancel()
        runCatching { wm.removeView(rootView) }
        super.onDestroy()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    // ---------- Floating overlay ----------
    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        fun btn(label: String, onClick: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { onClick() } }

        bubble = TextView(this).apply {
            text = "🤖"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC7C3AED")) }
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        input = EditText(this).apply {
            hint = "What should I do?"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); maxLines = 3
        }
        status = TextView(this).apply { text = "Ready"; textSize = 13f; setTextColor(Color.WHITE) }
        confirmRow = LinearLayout(this).apply {
            visibility = View.GONE
            addView(btn("Approve") { confirmation?.complete(true) })
            addView(btn("Deny") { confirmation?.complete(false) })
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#E61F1B2E")) }
            layoutParams = LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT)
            addView(input)
            addView(status)
            addView(LinearLayout(context).apply {
                addView(btn("Go") { startTask() })
                addView(btn("Stop") { stopTask("Stopped") })
            })
            addView(confirmRow)
        }
        rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(bubble); addView(panel) }

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = ev.rawX; ty = ev.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - tx; val dy = ev.rawY - ty
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt()
                    wm.updateViewLayout(rootView, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) setPanel(!panelOpen)
            }
            true
        }
        wm.addView(rootView, lp)
    }

    private fun setPanel(open: Boolean) {
        panelOpen = open
        panel.visibility = if (open) View.VISIBLE else View.GONE
        lp.flags = if (open) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(rootView, lp)
    }

    private fun say(msg: String) { status.text = msg }

    // ---------- Agent loop ----------
    private fun startTask() {
        val task = input.text.toString().trim()
        val prefs = getSharedPreferences("agent", MODE_PRIVATE)
        val provider = Providers.byId(prefs.getString("provider", "claude").orEmpty())
        val key = prefs.getString("key_${provider.id}", "").orEmpty()
        val model = prefs.getString("model_${provider.id}", "").orEmpty().ifBlank { provider.model }
        if (task.isEmpty()) return
        if (key.isEmpty()) { say("Add your ${provider.label} API key in the Phone Agent app"); return }
        // release keyboard focus so the app underneath becomes the active window again
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(rootView, lp)

        job?.cancel()
        val client = LlmClient(provider, key, model)
        job = scope.launch {
            val history = mutableListOf<String>()
            val allowed = mutableSetOf<String>()
            for (step in 1..25) {
                say("Step $step: looking at screen…")
                delay(700)
                val screen = readScreen() ?: run { say("Can't read this screen"); return@launch }
                if (isBlocked(screen.pkg, null) || Blocklist.screenBlocked(screen.text, extraBlocked())) {
                    say("🔒 Blocked: banking, wallet, trading and password screens are off-limits. Nothing was sent.")
                    return@launch
                }
                // Ask before the agent looks at (and sends to the AI) each new app
                if (screen.pkg !in allowed) {
                    say("👁 Allow the agent to look at \"${appLabel(screen.pkg)}\" and send it to the AI?")
                    confirmRow.visibility = View.VISIBLE
                    val answer = CompletableDeferred<Boolean>().also { confirmation = it }
                    val ok = answer.await()
                    confirmRow.visibility = View.GONE
                    if (!ok) { say("Permission denied. Stopped. Nothing was sent."); return@launch }
                    allowed.add(screen.pkg)
                }
                val reply = try {
                    withContext(Dispatchers.IO) { client.next(task, history, screen.text) }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { say("Error: ${e.message}"); return@launch }

                val action = reply.optString("action")
                val desc = reply.optString("say")
                if (action == "done") { say("✅ $desc"); return@launch }

                if (reply.optBoolean("risky")) {
                    say("⚠️ $desc")
                    confirmRow.visibility = View.VISIBLE
                    val answer = CompletableDeferred<Boolean>().also { confirmation = it }
                    val ok = answer.await()
                    confirmRow.visibility = View.GONE
                    if (!ok) { say("Denied. Stopped."); return@launch }
                }
                say("Step $step: $desc")
                val result = perform(reply, screen)
                history.add("$step. $desc -> $result")
            }
            say("Reached the 25-step limit")
        }
    }

    private fun stopTask(msg: String) {
        job?.cancel()
        confirmation?.complete(false)
        confirmRow.visibility = View.GONE
        say(msg)
    }

    // ---------- Safety block list ----------
    private fun extraBlocked() =
        getSharedPreferences("agent", MODE_PRIVATE).getString("blocked_extra", "").orEmpty()

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun isBlocked(pkg: String, label: String?): Boolean {
        if (pkg == packageName) return false
        val lbl = label ?: runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault("")
        return Blocklist.appBlocked(pkg, lbl, extraBlocked())
    }

    // ---------- Seeing ----------
    private fun readScreen(): Screen? {
        val root = rootInActiveWindow ?: return null
        val nodes = linkedMapOf<Int, AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (!n.isVisibleToUser) return
            val label = listOfNotNull(n.text, n.contentDescription).joinToString(" | ")
            if (n.isClickable || n.isEditable || n.isScrollable || label.isNotBlank()) {
                val i = nodes.size
                nodes[i] = n
                val flags = buildList {
                    if (n.isClickable) add("tap"); if (n.isEditable) add("edit")
                    if (n.isScrollable) add("scroll"); if (n.isChecked) add("checked")
                }
                sb.append("[$i] ${n.className?.toString()?.substringAfterLast('.')} \"${label.take(80)}\" ${flags.joinToString(",")}\n")
            }
            for (c in 0 until n.childCount) n.getChild(c)?.let { walk(it) }
        }
        walk(root)
        return Screen(sb.toString().take(12000), nodes, root.packageName?.toString().orEmpty())
    }

    // ---------- Touching ----------
    private suspend fun perform(a: JSONObject, s: Screen): String {
        val node = s.nodes[a.optInt("index", -1)]
        return when (a.optString("action")) {
            "tap" -> if (node == null) "bad index" else if (tap(node)) "ok" else "failed"
            "type" -> {
                if (node == null) return "bad index"
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                }
                val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (ok && a.optBoolean("submit")) {
                    delay(300)
                    node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
                if (ok) "ok" else "failed"
            }
            "scroll" -> scroll(node ?: s.nodes.values.firstOrNull { it.isScrollable }, a.optString("direction") != "up")
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "ok" }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "ok" }
            "open_app" -> openApp(a.optString("text"))
            "wait" -> { delay(1500); "ok" }
            else -> "unknown action"
        }
    }

    private suspend fun tap(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect().also { n.getBoundsInScreen(it) }
        return gesture(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), r.exactCenterY(), 60)
    }

    private suspend fun scroll(n: AccessibilityNodeInfo?, down: Boolean): String {
        val act = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (n != null && n.performAction(act)) return "ok"
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val (y1, y2) = if (down) m.heightPixels * 0.7f to m.heightPixels * 0.3f else m.heightPixels * 0.3f to m.heightPixels * 0.7f
        return if (gesture(x, y1, x, y2, 300)) "ok" else "failed"
    }

    private suspend fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        val done = CompletableDeferred<Boolean>()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { done.complete(true) }
            override fun onCancelled(d: GestureDescription?) { done.complete(false) }
        }, null)
        return done.await()
    }

    private fun openApp(name: String): String {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = packageManager.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(packageManager).toString().contains(name, ignoreCase = true) }
            ?: return "app not found"
        if (isBlocked(match.activityInfo.packageName, match.loadLabel(packageManager).toString())) {
            return "blocked: this app is on the safety block list, choose a different approach or finish with done"
        }
        val intent = packageManager.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "can't launch"
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok"
    }
}
