package com.example.phoneagent

data class Provider(
    val id: String,
    val label: String,
    val url: String,
    val model: String,
    val anthropicFormat: Boolean
)

object Providers {
    val all = listOf(
        Provider("claude", "Claude (Anthropic)", "https://api.anthropic.com/v1/messages", "claude-sonnet-5-5", true),
        Provider("deepseek", "DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-v4-flash", false),
        Provider("qwen", "Qwen (international)", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen-plus", false),
        Provider("qwen_cn", "Qwen (China region)", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen-plus", false)
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]
}
