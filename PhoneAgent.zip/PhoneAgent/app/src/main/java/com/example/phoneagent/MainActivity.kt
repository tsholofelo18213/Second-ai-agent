package com.example.phoneagent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("agent", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val picker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Providers.all.map { it.label })
            setSelection(Providers.all.indexOf(Providers.byId(prefs.getString("provider", "claude")!!)))
        }
        val key = EditText(this).apply {
            hint = "API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT }
        val extra = EditText(this).apply {
            hint = "Extra blocked words, comma-separated (e.g. your bank's name)"
            setText(prefs.getString("blocked_extra", ""))
        }

        fun load(p: Provider) {
            key.setText(prefs.getString("key_${p.id}", ""))
            model.setText(prefs.getString("model_${p.id}", ""))
            model.hint = "Model (optional, default: ${p.model})"
        }
        picker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val p = Providers.all[pos]
                prefs.edit().putString("provider", p.id).apply()
                load(p)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(TextView(this@MainActivity).apply { text = "Phone Agent"; textSize = 24f })
            addView(TextView(this@MainActivity).apply {
                text = "1. Pick the AI provider, paste its API key, and save.\n2. Enable \"Phone Agent\" in Accessibility settings.\n3. Tap the floating robot in any app, type a task, press Go.\n\nIf the toggle is greyed out: App info > ⋮ > Allow restricted settings."
                setPadding(0, pad / 2, 0, pad / 2)
            })
            addView(picker)
            addView(key)
            addView(model)
            addView(extra)
            addView(Button(this@MainActivity).apply {
                text = "Save"
                setOnClickListener {
                    val p = Providers.all[picker.selectedItemPosition]
                    prefs.edit()
                        .putString("provider", p.id)
                        .putString("key_${p.id}", key.text.toString().trim())
                        .putString("model_${p.id}", model.text.toString().trim())
                        .putString("blocked_extra", extra.text.toString().trim())
                        .apply()
                    Toast.makeText(context, "Saved for ${p.label}", Toast.LENGTH_SHORT).show()
                }
            })
            addView(Button(this@MainActivity).apply {
                text = "Open Accessibility settings"
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            })
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
